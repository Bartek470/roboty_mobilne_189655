
#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>
#include <webots/supervisor.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdio.h>


#define TIME_STEP 64

int main(int argc, char **argv) {
  wb_robot_init();
  srand(time(NULL));
  float a = 8.0;
  bool avoid_obstacle_counter = 0;
  bool krawedz_wykryta = false;
  int counter_obracania_sie = 0;
  WbDeviceTag wheels[4];
  char wheels_names[4][8] = {
  "wheel1", "wheel2", "wheel3", "wheel4" };
  int i;
  for(i = 0; i < 4; i++) {
    wheels[i] = wb_robot_get_device(wheels_names[i]);
    wb_motor_set_position(wheels[i], INFINITY);
  }
  WbDeviceTag ds[2];
  char ds_names[2][20] = {
  "czujnik_krawedzi", "czujnik_przeszkody" };
  for(i = 0; i < 2; i++){
    ds[i] = wb_robot_get_device(ds_names[i]);
    wb_distance_sensor_enable(ds[i], TIME_STEP);
  }
  WbNodeRef root_node = wb_supervisor_node_get_root();
  WbFieldRef children_field = wb_supervisor_node_get_field(root_node, "children");
  
  for (int j = 0; j < 8; j++){
    float x = ((float)rand()/(float)(RAND_MAX)) * a - 4;
    float y = ((float)rand()/(float)(RAND_MAX)) * a - 4;
    char x1[5];
    char y1[5];
    sprintf(x1, "%d.%d", (int)x, (int)abs((x * 10) - (int)x * 10) );
    sprintf(y1, "%d.%d", (int)y, (int)abs((y * 10) - (int)y * 10) );
    char instrukcja[30];
    strcpy(instrukcja, "Ball {translation ");
    strcat(instrukcja, x1);
    strcat(instrukcja, " ");
    strcat(instrukcja, y1);
    strcat(instrukcja, " 1}");
    wb_supervisor_field_import_mf_node_from_string(children_field, -1, instrukcja);
  }
  for (int j = 0; j < 8; j++){
    float x = ((float)rand()/(float)(RAND_MAX)) * a - 4;
    float y = ((float)rand()/(float)(RAND_MAX)) * a - 4;
    char x1[5];
    char y1[5];
    sprintf(x1, "%d.%d", (int)x, (int)abs((x * 10) - (int)x * 10) );
    sprintf(y1, "%d.%d", (int)y, (int)abs((y * 10) - (int)y * 10) );
    char instrukcja[50];
    strcpy(instrukcja, "SoccerBall {translation ");
    strcat(instrukcja, x1);
    strcat(instrukcja, " ");
    strcat(instrukcja, y1);
    strcat(instrukcja, " 1 ");
    strcat(instrukcja, "radius 0.05 mass 1}");
    wb_supervisor_field_import_mf_node_from_string(children_field, -1, instrukcja);
  }
  for (int j = 0; j < 8; j++){
    float x = ((float)rand()/(float)(RAND_MAX)) * a - 4;
    float y = ((float)rand()/(float)(RAND_MAX)) * a - 4;
    char x1[5];
    char y1[5];
    sprintf(x1, "%d.%d", (int)x, (int)abs((x * 10) - (int)x * 10) );
    sprintf(y1, "%d.%d", (int)y, (int)abs((y * 10) - (int)y * 10) );
    char instrukcja[50];
    strcpy(instrukcja, "Apple {translation ");
    strcat(instrukcja, x1);
    strcat(instrukcja, " ");
    strcat(instrukcja, y1);
    strcat(instrukcja, " 1 ");
    strcat(instrukcja, "}");
    wb_supervisor_field_import_mf_node_from_string(children_field, -1, instrukcja);
  }
  //wb_supervisor_field_import_mf_node_from_string(children_field, -1, "Ball { translation 0 0 1 }");
  //wb_supervisor_field_import_mf_node_from_string(children_field, -1, "Ball { translation 1 1 1 }");
  //WbNodeRef ball_node = wb_supervisor_node_get_from_def("BALL");
  
  //wb_supervisor_field_import_mf_node_from_string(children_field, -1, "DEF BALL Ball { translation 0 2 2 }");
  //WbNodeRef ball_node1 = wb_supervisor_node_get_from_def("BALL");
  while (wb_robot_step(TIME_STEP) != -1) {
    double left_speed = 3.0;
    double right_speed = 3.0;
    
    //wykrywanie krawędzi
    if(avoid_obstacle_counter > 0){
      avoid_obstacle_counter--;
      left_speed = 3.0;
      right_speed = -3.0;
    }
    else {
      double ds_value;
        ds_value = wb_distance_sensor_get_value(ds[0]);
        if (ds_value > 200.0) {
          avoid_obstacle_counter = 23;
          krawedz_wykryta = true;
        }
    }
    
    //wykrywanie przeszkody
    if (!krawedz_wykryta) {
      double ds_value = wb_distance_sensor_get_value(ds[1]);
      if (ds_value > 38000) {
        left_speed = 1.0;
        right_speed = -1.0;
        counter_obracania_sie++;
      }
      else {
        counter_obracania_sie = 0;
      }
    }
    
    if (counter_obracania_sie > 360){
      left_speed = 0.0;
      right_speed = 0.0;
    }
    wb_motor_set_velocity(wheels[0], left_speed);
    wb_motor_set_velocity(wheels[1], right_speed);
    wb_motor_set_velocity(wheels[2], left_speed);
    wb_motor_set_velocity(wheels[3], right_speed);
    if (avoid_obstacle_counter == 0){
      krawedz_wykryta = false;
    }
  };
  wb_robot_cleanup();

  return 0;
}
