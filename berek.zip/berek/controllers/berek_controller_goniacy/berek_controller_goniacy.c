#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

#define TIME_STEP 64

bool uciekajacy = false;
double a = 4.0;
double b = 1.0;
double c = 6.0;
double left_speed = 1.0;
double right_speed = 1.0;
int counter_obrotu = 0;

bool obrot_180 = false;
bool headstart = false;
int headstart_timer = 0;

void obrot_180_stopni();

int main(int argc, char **argv) {
  wb_robot_init();

  srand(time(NULL));

  WbDeviceTag wheels[4];
  char wheels_names[4][8] = {
  "wheel1", "wheel2", "wheel3", "wheel4" };
  int i;
  for(i = 0; i < 4; i++) {
    wheels[i] = wb_robot_get_device(wheels_names[i]);
    wb_motor_set_position(wheels[i], INFINITY);
  }
  
  WbDeviceTag ds[4];
  char ds_names[4][25] = {
  "czujnik_berek_przedni", "czujnik_berek_tylny", "czujnik_lewy", "czujnik_prawy" };
  for(i = 0; i < 4; i++){
    ds[i] = wb_robot_get_device(ds_names[i]);
    wb_distance_sensor_enable(ds[i], TIME_STEP);
  }
  
  while (wb_robot_step(TIME_STEP) != -1) {
    
    double ds_values[4];
    ds_values[0] = wb_distance_sensor_get_value(ds[0]);
    ds_values[1] = wb_distance_sensor_get_value(ds[1]);
    ds_values[2] = wb_distance_sensor_get_value(ds[2]);
    ds_values[3] = wb_distance_sensor_get_value(ds[3]);
    
    if (uciekajacy && !obrot_180) {
      if (ds_values[1] < 600 && !headstart){
        //został dogoniony
        uciekajacy = false;
        obrot_180 = true;
      }
      else {
        left_speed = ((double)rand()/(double)RAND_MAX) * a;
        double x = ((double)rand()/(double)RAND_MAX) * b - (b/2);
        right_speed = left_speed + x;
      }
    }
    
    else if (!uciekajacy && !obrot_180 && !headstart) {
      if (ds_values[0] < 600 && !headstart) {
        uciekajacy = true;
        obrot_180 = true;
        //obrot o 180 stopni
      }
      else if (ds_values[2] < 20000 && ds_values[0] > 30000) {
        //skret w lewo
        left_speed = -3.0;
        right_speed = 3.0;
      }
      else if (ds_values[3] < 20000 && ds_values[0] > 30000) {
        //skret w prawo
        left_speed = 3.0;
        right_speed = -3.0;
      }
      else {
        left_speed = ((double)rand()/(double)RAND_MAX) * c;
        right_speed = left_speed;
      }
    }
    
    if (headstart && headstart_timer > 0){
      headstart_timer--;
      if (headstart_timer == 0){
        headstart = false;
      }
    }
    
    if (obrot_180) {
      obrot_180_stopni();
    }
    
    if (!uciekajacy){
      printf("Left speed: %f\n", left_speed);
      printf("Right speed: %f\n", right_speed);
      printf("Czujnik przedni: %f\n", ds_values[0]);
      //if (obrot_180) {
        //printf("Obracam sie o 180\n");
      //}
    }
    
    //if (uciekajacy && obrot_180){
      //printf("Obracam sie o 180 i jestem uciekajacy\n");
    //}
    
    wb_motor_set_velocity(wheels[0], left_speed);
    wb_motor_set_velocity(wheels[1], right_speed);
    wb_motor_set_velocity(wheels[2], left_speed);
    wb_motor_set_velocity(wheels[3], right_speed);
  };

  wb_robot_cleanup();

  return 0;
}

void obrot_180_stopni(){
  if (counter_obrotu == 0){
    counter_obrotu = 180;
  }
  else {
    left_speed = ((M_PI/2)/50)/ 0.0449141;
    right_speed = -((M_PI/2)/50)/ 0.0449141;
    counter_obrotu--;
    if (counter_obrotu == 0){
      obrot_180 = false;
      headstart = true;
      headstart_timer = 250;
      printf("Koncze obrot\n");
      left_speed = 0.0;
      right_speed = 0.0;
    }
  }
}
