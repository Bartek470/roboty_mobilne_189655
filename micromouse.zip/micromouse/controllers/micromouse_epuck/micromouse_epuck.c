
#include <webots/robot.h>
#include <webots/distance_sensor.h>
#include <webots/motor.h>
#include <webots/supervisor.h>
#include <stddef.h>
#include <stdio.h>
#include <math.h>

#define TIME_STEP 64
#define MAX_SPEED 6.28

//małe zielone kulki ukazują punkt startowy i końcowy

struct pole_planszy {
  bool lewe_pole_dostepne;
  bool gorne_pole_dostepne;
  bool prawe_pole_dostepne;
  bool dolne_pole_dostepne;
  int skad_przyszedl; //1 - lewo, 2 - góra, 3 - prawo, 4 - dół
  bool odwiedzone;
  bool zbior_q;
  int koszt_dotarcia;
  int skad_przyszedl_x_dijkstra;
  int skad_przyszedl_y_dijkstra;
};

struct pole_planszy pola_planszy[10][10];
int aktualny_x = 0;
int aktualny_y = 3;
int poprzedni_x = 0;
int poprzedni_y = 0;

int aktualny_obrot = 4; //podobnie jak wyżej
int docelowy_obrot = 4;

int docelowy_x = 9;
int docelowy_y = 6;

int counter_jazdy = 0;
int counter_obrotu = 0;
int opoznienie = 5;
bool znaleziono_kierunek = false;
bool koniec_programu = false;

bool jazda = false;
bool obrot_ = false;

bool przeszukiwanie = false;
bool trasa_ = false;
bool przejazd_trasy = false;
bool dijkstra = false;
int x_trasy = 0;
int y_trasy = 0;
int krok_trasy = 99;
int trasa[100];

double left_speed = 0.0;
double right_speed = 0.0;
double ps_values[8];

int i;
  WbDeviceTag ps[8];
  char ps_names[8][4] = {
  "ps0", "ps1", "ps2", "ps3",
  "ps4", "ps5", "ps6", "ps7" };
  
void jedz_w_przod();
void obrot();
void przeszukanie();
void algorytm_dijkstry();
void wyznaczenie_trasy();

int main(int argc, char **argv) {
  wb_robot_init();
  
  for(i = 0; i < 8; i++){
    ps[i] = wb_robot_get_device(ps_names[i]);
    wb_distance_sensor_enable(ps[i], TIME_STEP);
  }
  
  WbDeviceTag left_motor = wb_robot_get_device("left wheel motor");
  WbDeviceTag right_motor = wb_robot_get_device("right wheel motor");
  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);
  wb_motor_set_velocity(left_motor, 0.0);
  wb_motor_set_velocity(right_motor, 0.0);
  
  for(int k = 0; k < 10; k++){
    for(int j = 0; j < 10; j++){
      pola_planszy[k][j].odwiedzone = false;
      pola_planszy[k][j].zbior_q = true;
      pola_planszy[k][j].koszt_dotarcia = 1000;
    }
  }
  
  pola_planszy[0][3].koszt_dotarcia = 0;
  
  for (int j = 0; j < 100; j++){
    trasa[j] = 0;
  }
  
  while (wb_robot_step(TIME_STEP) != -1) {
  if(!koniec_programu){
    for(int i = 0; i < 8; i++){
      ps_values[i] = wb_distance_sensor_get_value(ps[i]);
    }
    left_speed = 0.0;
    right_speed = 0.0;
    
    if(opoznienie != 0) {
      opoznienie--;
      if(opoznienie == 0) {
        przeszukiwanie = true;
      }
    }
    else opoznienie = 0;
    
    if (przeszukiwanie) {
        przeszukanie();
    }
    
      if (obrot_){
        obrot();
        if (aktualny_obrot != docelowy_obrot){
          obrot_ = true;
        }
        else {
          obrot_ = false;
          jazda = true;
        }
      }
      
      if (docelowy_obrot == aktualny_obrot){
        obrot_ = false;
        jazda = true;
      }
      
      if (trasa_) jazda = false;
      if (jazda && !dijkstra){
        jedz_w_przod();
        if (!jazda && przejazd_trasy == false && dijkstra == false){
          przeszukiwanie = true;
        }
        else if (!jazda && przejazd_trasy){
          if (krok_trasy != 99){
            krok_trasy++;
          }
          else {
            koniec_programu = true;
          }
        }
      }
      
      
    if(opoznienie == 0 && aktualny_x == 0 && aktualny_y == 3 && !jazda && !dijkstra && !obrot_ && !trasa_ && !przejazd_trasy){
      //koniec przeszukiwania
      przeszukiwanie = false;
      //printf("Skonczylem przeszukiwanie");
      dijkstra = true;
      //printf("Wchodze do Dijkstry");
    }
    
    if (dijkstra && !przejazd_trasy) {
      algorytm_dijkstry();
      if (!dijkstra){
        trasa_ = true;
        x_trasy = docelowy_x;
        y_trasy = docelowy_y;
      }
    }
    
    if(trasa_ && !dijkstra){
      wyznaczenie_trasy();
      if (!trasa_) {
        przejazd_trasy = true;
      }
    }
    
    /*if(!przeszukiwanie && !jazda && !obrot_ && opoznienie == 0 && !przejazd_trasy){
      algorytm_dijkstry();
      trasa_ = true;
      x_trasy = docelowy_x;
      y_trasy = docelowy_y;
      wyznaczenie_trasy();
      przejazd_trasy = true;
    }*/
    
    if(przejazd_trasy) {
      switch (trasa[krok_trasy]){
        case 0:
          krok_trasy++;
          docelowy_obrot = 4;
        break;
        case 1:
          docelowy_obrot = 1;
        break;
        case 2:
          docelowy_obrot = 2;
        break;
        case 3:
          docelowy_obrot = 3;
        break;
        case 4:
          docelowy_obrot = 4;
        break;
      }
      //printf("Zmieniam docelowy obrot: %d\n", docelowy_obrot);
        if (docelowy_obrot != aktualny_obrot){
            obrot_ = true;
        }
    }
    
    //printf("Aktualny x: %d\n", aktualny_x);
    //printf("Aktualny y: %d\n", aktualny_y);
    //printf("Aktualne opoznienie: %d\n", opoznienie);
    if (koniec_programu){
      left_speed = 0.0;
      right_speed = 0.0;
    }
    wb_motor_set_velocity(left_motor, left_speed);
    wb_motor_set_velocity(right_motor, right_speed);
    }
  };
  

  wb_robot_cleanup();

  return 0;
}


void jedz_w_przod(){
  if (counter_jazdy == 0) {
    counter_jazdy = 50;
  }
  else {
    left_speed = 1.953125;
    right_speed = 1.953125;
    counter_jazdy--;
    if (counter_jazdy == 0){
      jazda = false;
    }
  }
}
//0.0449141
void obrot(){
  if (counter_obrotu == 0) {
    counter_obrotu = 50;
  }
  else {
  if ((aktualny_obrot == 4 && docelowy_obrot == 1) || (docelowy_obrot > aktualny_obrot && 
  (aktualny_obrot != 1 || docelowy_obrot != 4))){
    left_speed = ((M_PI/2)/50)/ 0.0449141;  //0.69953076232237658393735100941427
    right_speed = -((M_PI/2)/50)/ 0.0449141;
    counter_obrotu--;
    if (counter_obrotu == 0){
      obrot_ = false;
      if(aktualny_obrot == 4){
        aktualny_obrot = 1;
      }
      else aktualny_obrot++;
      }
    }
    else {
    left_speed = -((M_PI/2)/50)/ 0.0449141;  //0.69953076232237658393735100941427
    right_speed = ((M_PI/2)/50)/ 0.0449141;
    counter_obrotu--;
    if (counter_obrotu == 0){
      obrot_ = false;
      if(aktualny_obrot == 1){
        aktualny_obrot = 4;
      }
      else aktualny_obrot--;
    }
  }
}
}

void przeszukanie(){
      if(ps_values[0] > 80.0 && ps_values[7] > 80.0){
        switch (aktualny_obrot){
          case 1:
            pola_planszy[aktualny_x][aktualny_y].lewe_pole_dostepne = false;
          break;
          case 2:
            pola_planszy[aktualny_x][aktualny_y].gorne_pole_dostepne = false;
          break;
          case 3:
            pola_planszy[aktualny_x][aktualny_y].prawe_pole_dostepne = false;
          break;
          case 4:
            pola_planszy[aktualny_x][aktualny_y].dolne_pole_dostepne = false;
          break;
          default:
          break;
        }
      }
      else {
      switch (aktualny_obrot){
          case 1:
            pola_planszy[aktualny_x][aktualny_y].lewe_pole_dostepne = true;
          break;
          case 2:
            pola_planszy[aktualny_x][aktualny_y].gorne_pole_dostepne = true;
          break;
          case 3:
            pola_planszy[aktualny_x][aktualny_y].prawe_pole_dostepne = true;
          break;
          case 4:
            pola_planszy[aktualny_x][aktualny_y].dolne_pole_dostepne = true;
          break;
          default:
          break;
        }
      }
      if(ps_values[2] > 80.0){
      switch (aktualny_obrot){
          case 1:
            pola_planszy[aktualny_x][aktualny_y].gorne_pole_dostepne = false;
          break;
          case 2:
            pola_planszy[aktualny_x][aktualny_y].prawe_pole_dostepne = false;
          break;
          case 3:
            pola_planszy[aktualny_x][aktualny_y].dolne_pole_dostepne = false;
          break;
          case 4:
            pola_planszy[aktualny_x][aktualny_y].lewe_pole_dostepne = false;
          break;
          default:
          break;
        }
      }
      else {
      switch (aktualny_obrot){
          case 1:
            pola_planszy[aktualny_x][aktualny_y].gorne_pole_dostepne = true;
          break;
          case 2:
            pola_planszy[aktualny_x][aktualny_y].prawe_pole_dostepne = true;
          break;
          case 3:
            pola_planszy[aktualny_x][aktualny_y].dolne_pole_dostepne = true;
          break;
          case 4:
            pola_planszy[aktualny_x][aktualny_y].lewe_pole_dostepne = true;
          break;
          default:
          break;
        }
      }
      if(ps_values[5] > 80.0){
      switch (aktualny_obrot){
          case 1:
            pola_planszy[aktualny_x][aktualny_y].dolne_pole_dostepne = false;
          break;
          case 2:
            pola_planszy[aktualny_x][aktualny_y].lewe_pole_dostepne = false;
          break;
          case 3:
            pola_planszy[aktualny_x][aktualny_y].gorne_pole_dostepne = false;
          break;
          case 4:
            pola_planszy[aktualny_x][aktualny_y].prawe_pole_dostepne = false;
          break;
          default:
          break;
        }
      }
      else {
      switch (aktualny_obrot){
          case 1:
            pola_planszy[aktualny_x][aktualny_y].dolne_pole_dostepne = true;
          break;
          case 2:
            pola_planszy[aktualny_x][aktualny_y].lewe_pole_dostepne = true;
          break;
          case 3:
            pola_planszy[aktualny_x][aktualny_y].gorne_pole_dostepne = true;
          break;
          case 4:
            pola_planszy[aktualny_x][aktualny_y].prawe_pole_dostepne = true;
          break;
          default:
          break;
        }
      }
      if (ps_values[3] > 80.0 && ps_values[4] > 80.0){
      switch (aktualny_obrot){
          case 1:
            pola_planszy[aktualny_x][aktualny_y].prawe_pole_dostepne = false;
          break;
          case 2:
            pola_planszy[aktualny_x][aktualny_y].dolne_pole_dostepne = false;
          break;
          case 3:
            pola_planszy[aktualny_x][aktualny_y].lewe_pole_dostepne = false;
          break;
          case 4:
            pola_planszy[aktualny_x][aktualny_y].gorne_pole_dostepne = false;
          break;
          default:
          break;
        }
      }
      else {
      switch (aktualny_obrot){
          case 1:
            pola_planszy[aktualny_x][aktualny_y].prawe_pole_dostepne = true;
          break;
          case 2:
            pola_planszy[aktualny_x][aktualny_y].dolne_pole_dostepne = true;
          break;
          case 3:
            pola_planszy[aktualny_x][aktualny_y].lewe_pole_dostepne = true;
          break;
          case 4:
            pola_planszy[aktualny_x][aktualny_y].gorne_pole_dostepne = true;
          break;
          default:
          break;
        }
      }
      pola_planszy[aktualny_x][aktualny_y].odwiedzone = true;
      znaleziono_kierunek = false;
      if(aktualny_x != 0 && !znaleziono_kierunek){
        if ((pola_planszy[aktualny_x][aktualny_y].lewe_pole_dostepne == true) && pola_planszy[aktualny_x - 1][aktualny_y].odwiedzone == false){
          docelowy_obrot = 1;
          if (docelowy_obrot != aktualny_obrot){
            obrot_ = true;
          }
          aktualny_x--;
          pola_planszy[aktualny_x][aktualny_y].skad_przyszedl = 3;
          znaleziono_kierunek = true;
        }
      }
      if(aktualny_y != 0 && !znaleziono_kierunek){
        if ((pola_planszy[aktualny_x][aktualny_y].gorne_pole_dostepne == true) && pola_planszy[aktualny_x][aktualny_y - 1].odwiedzone == false){
          docelowy_obrot = 2;
          if (docelowy_obrot != aktualny_obrot){
            obrot_ = true;
          }
          aktualny_y--;
          pola_planszy[aktualny_x][aktualny_y].skad_przyszedl = 4;
          znaleziono_kierunek = true;
        }
      }
      if(aktualny_x != 9 && !znaleziono_kierunek){
        if ((pola_planszy[aktualny_x][aktualny_y].prawe_pole_dostepne == true) && pola_planszy[aktualny_x + 1][aktualny_y].odwiedzone == false){
          docelowy_obrot = 3;
          if (docelowy_obrot != aktualny_obrot){
            obrot_ = true;
          }
          aktualny_x++;
          pola_planszy[aktualny_x][aktualny_y].skad_przyszedl = 1;
          znaleziono_kierunek = true;
        }
      }
      if(aktualny_y != 9 && !znaleziono_kierunek){
        if ((pola_planszy[aktualny_x][aktualny_y].dolne_pole_dostepne == true) && pola_planszy[aktualny_x][aktualny_y + 1].odwiedzone == false){
          docelowy_obrot = 4;
          if (docelowy_obrot != aktualny_obrot){
            obrot_ = true;
          }
          aktualny_y++;
          pola_planszy[aktualny_x][aktualny_y].skad_przyszedl = 2;
          znaleziono_kierunek = true;
        }
      }
      if (!znaleziono_kierunek){
        docelowy_obrot = pola_planszy[aktualny_x][aktualny_y].skad_przyszedl;
        if (docelowy_obrot != aktualny_obrot){
            obrot_ = true;
          }
        switch (docelowy_obrot) {
          case 1:
            aktualny_x--;
          break;
          case 2:
            if (aktualny_y == 4 && aktualny_x == 0){
              //printf("Zmieniam y %d", aktualny_y);
            }
            aktualny_y--;
          break;
          case 3:
            aktualny_x++;
          break;
          case 4:
            aktualny_y++;
          break;
        }
      }
      
      przeszukiwanie = false;
}

void algorytm_dijkstry(){
  int minimum = 1001;
  int x_minimum = -1;
  int y_minimum = -1;
  bool zbior_q_pusty = true;
  
  for (int k = 0; k < 10; k++){
    for (int j = 0; j < 10; j++){
      if (pola_planszy[k][j].zbior_q && pola_planszy[k][j].koszt_dotarcia < minimum){
        minimum = pola_planszy[k][j].koszt_dotarcia;
        x_minimum = k;
        y_minimum = j;
      }
    }
  }
  
  //printf("Minimum: %d\n", minimum);
  //printf("X : %d\n", x_minimum);
  //printf("Y: %d\n", y_minimum);
  
  pola_planszy[x_minimum][y_minimum].zbior_q = false;
  if(pola_planszy[x_minimum][y_minimum].lewe_pole_dostepne){
    if(pola_planszy[x_minimum - 1][y_minimum].koszt_dotarcia > pola_planszy[x_minimum][y_minimum].koszt_dotarcia + 1){
      pola_planszy[x_minimum - 1][y_minimum].koszt_dotarcia = pola_planszy[x_minimum][y_minimum].koszt_dotarcia + 1;
      pola_planszy[x_minimum - 1][y_minimum].skad_przyszedl_x_dijkstra = x_minimum;
      pola_planszy[x_minimum - 1][y_minimum].skad_przyszedl_y_dijkstra = y_minimum;
    }
  }
  if(pola_planszy[x_minimum][y_minimum].gorne_pole_dostepne){
    if(pola_planszy[x_minimum][y_minimum - 1].koszt_dotarcia > pola_planszy[x_minimum][y_minimum].koszt_dotarcia + 1){
      pola_planszy[x_minimum][y_minimum - 1].koszt_dotarcia = pola_planszy[x_minimum][y_minimum].koszt_dotarcia + 1;
      pola_planszy[x_minimum][y_minimum - 1].skad_przyszedl_x_dijkstra = x_minimum;
      pola_planszy[x_minimum][y_minimum - 1].skad_przyszedl_y_dijkstra = y_minimum;
    }
  }
  if(pola_planszy[x_minimum][y_minimum].prawe_pole_dostepne){
    if(pola_planszy[x_minimum + 1][y_minimum].koszt_dotarcia > pola_planszy[x_minimum][y_minimum].koszt_dotarcia + 1){
      pola_planszy[x_minimum + 1][y_minimum].koszt_dotarcia = pola_planszy[x_minimum][y_minimum].koszt_dotarcia + 1;
      pola_planszy[x_minimum + 1][y_minimum].skad_przyszedl_x_dijkstra = x_minimum;
      pola_planszy[x_minimum + 1][y_minimum].skad_przyszedl_y_dijkstra = y_minimum;
    }
  }
  if(pola_planszy[x_minimum][y_minimum].dolne_pole_dostepne){
    if(pola_planszy[x_minimum][y_minimum + 1].koszt_dotarcia > pola_planszy[x_minimum][y_minimum].koszt_dotarcia + 1){
      pola_planszy[x_minimum][y_minimum + 1].koszt_dotarcia = pola_planszy[x_minimum][y_minimum].koszt_dotarcia + 1;
      pola_planszy[x_minimum][y_minimum + 1].skad_przyszedl_x_dijkstra = x_minimum;
      pola_planszy[x_minimum][y_minimum + 1].skad_przyszedl_y_dijkstra = y_minimum;
    }
  }
  
  for (int k = 0; k < 10; k++){
    for (int j = 0; j < 10; j++){
      if(pola_planszy[k][j].zbior_q == true){
        zbior_q_pusty = false;
      }
    }
  }
  
  //printf("Robie krok dijkstry");
  
  if (zbior_q_pusty == true){
    dijkstra = false;
  }
}

void wyznaczenie_trasy(){
  
 // printf("X trasy: %d\n", x_trasy);
  //printf("Y trasy: %d\n", y_trasy);
  if(pola_planszy[x_trasy][y_trasy].skad_przyszedl_x_dijkstra - x_trasy == 1){
    trasa[krok_trasy] = 1;
    x_trasy++;
  }
  else if(pola_planszy[x_trasy][y_trasy].skad_przyszedl_x_dijkstra - x_trasy == -1){
    trasa[krok_trasy] = 3;
    x_trasy--;
  }
  else if(pola_planszy[x_trasy][y_trasy].skad_przyszedl_y_dijkstra - y_trasy == 1){
    trasa[krok_trasy] = 2;
    y_trasy++;
  }
  else if(pola_planszy[x_trasy][y_trasy].skad_przyszedl_y_dijkstra - y_trasy == -1){
    trasa[krok_trasy] = 4;
    y_trasy--;
  }
  //x_trasy = pola_planszy[x_trasy][y_trasy].skad_przyszedl_x_dijkstra;
  //y_trasy = pola_planszy[x_trasy][y_trasy].skad_przyszedl_y_dijkstra;
  krok_trasy--;
  if (x_trasy == 0 && y_trasy == 3){
    trasa_ = false;
    krok_trasy = 0;
   // for(int k = 0; k < 100; k++){
      //printf("Krok trasy: %d\n", trasa[k]);
   // }
  }
}














